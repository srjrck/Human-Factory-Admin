<!DOCTYPE html>
<html lang="en">

@include('Admin/Layouts/Head')

<body>

  @include('Admin/Layouts/Menu')
  @include('Admin/Layouts/Header')

    <div class="clearfix"></div>
    <div class="content-wrapper">
      <div class="container-fluid">
      	<div class="row mt-4">
          <div class="col-12 col-lg-6 col-xl-3">
            <div class="card gradient-purpink">
              <div class="card-body">
                <div class="media">
                  <div class="media-body text-left">
                    <h4 class="text-white">{{$Practitioner}}</h4>
                    <span class="text-white">Total Practitioner</span>
                  </div>
                  <div class="align-self-center"><span id="dash-chart-1"></span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-6 col-xl-3">
            <div class="card gradient-purpink">
              <div class="card-body">
                <div class="media">
                  <div class="media-body text-left">
                    <h4 class="text-white">{{$Careteam}}</h4>
                    <span class="text-white">Total Careteam</span>
                  </div>
                  <div class="align-self-center"><span id="dash-chart-1"></span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-6 col-xl-3">
            <div class="card gradient-purpink">
              <div class="card-body">
                <div class="media">
                  <div class="media-body text-left">
                    <h4 class="text-white">{{$Encounter}}</h4>
                    <span class="text-white">Total Encounters</span>
                  </div>
                  <div class="align-self-center"><span id="dash-chart-1"></span></div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-6 col-xl-3">
            <div class="card gradient-purpink">
              <div class="card-body">
                <div class="media">
                  <div class="media-body text-left">
                    <h4 class="text-white">{{$Patient}}</h4>
                    <span class="text-white">Total Patients</span>
                  </div>
                  <div class="align-self-center"><span id="dash-chart-1"></span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
  @include('Admin/Layouts/Footer')
    
  <script src="{{ asset('public/Admin')}}/assets/js/index.js"></script>
  
</body>
</html>