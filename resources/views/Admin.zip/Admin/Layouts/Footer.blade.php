  <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
  <!-- <footer class="footer">
    <div class="container">
      <div class="text-center">
        Copyright © {{date('Y')}} DashRock Admin
      </div>
    </div>
  </footer> -->
</div>
<script src="{{ asset('public/Admin')}}/assets/js/jquery.min.js"></script>
<script src="{{ asset('public/Admin')}}/assets/js/popper.min.js"></script>
<script src="{{ asset('public/Admin')}}/assets/js/bootstrap.min.js"></script>

<script src="{{ asset('public/Admin')}}/assets/plugins/simplebar/js/simplebar.js"></script>
<script src="{{ asset('public/Admin')}}/assets/js/sidebar-menu.js"></script>
<script src="{{ asset('public/Admin')}}/assets/js/app-script.js"></script>

<script src="{{ asset('public/Admin')}}/assets/js/jquery.validate.min.js"></script>
<script src="{{ asset('public/Admin')}}/assets/js/additional-methods.min.js"></script>  